import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import RaisedButton from 'material-ui/RaisedButton';
import TextField from 'material-ui/TextField';
import './LoginForm.css';

class LoginForm extends Component {
  constructor(props){
    super(props);

    this.usernameNode = React.createRef();
    this.passwordNode = React.createRef();

    this.state = {
      username: '',
      password: '',
    }
  }

  handleUsernameChange = (event) => {
    console.log('handleUsernameChange: ', event.target.value);
    // TODO: check event.target.value for valid symbols
  }

  handlePasswordChange = (event) => {
    console.log('handlePasswordChange: ', event.target.value);
    // TODO: check event.target.value for valid symbols
  }

  handleSubmitClick = (event) => {
    const username = this.usernameNode.current;
    const password = this.passwordNode.current;

    console.group('in handleSubmitClick');
    console.log('username: ', username);
    console.log('password: ', password);
    console.groupEnd();

    // TODO: do some stuff with values to provide submitting
    // TODO: provide additional functionality
  }

  render() {
    return (
      <div className="LoginForm">
        <MuiThemeProvider>
          <div>
            <AppBar
               title="Login"
             />

            <TextField
              ref={this.usernameNode}
              className="LoginForm--text-input"
              hintText="Enter your Username"
              floatingLabelText="Username"
              onChange={(event) => this.handleUsernameChange(event)}
            />

            <br/>

            <TextField
              ref={this.passwordNode}
              className="LoginForm--text-input"
              type="password"
              hintText="Enter your Password"
              floatingLabelText="Password"
              onChange={(event) => this.handlePasswordChange(event)}
            />

            <br/>

            <RaisedButton
              className="LoginForm--submit"
              label="Submit"
              primary={true}
              onClick={(event) => this.handleSubmitClick(event)}
            />
          </div>
        </MuiThemeProvider>
      </div>
    );
  }
}

export default LoginForm;
